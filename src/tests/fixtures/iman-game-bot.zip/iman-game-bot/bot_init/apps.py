from django.apps import AppConfig


class BotInitConfig(AppConfig):
    name = 'bot_init'
